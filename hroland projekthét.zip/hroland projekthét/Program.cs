﻿using System.Security;
using System.Security.AccessControl;

namespace zsimbo_projecthet_1;

class Program
{
	public static Random rand = new();

	static void Main(string[] args)
	{
		while (true)
		{
			Console.Clear();

			List<int> restaurants = new();
			int i;

			for (i = 0; i < 18; i++)
				restaurants.Add(rand.Next(30, 81));

			Console.Write("Masodik 9 etterem kozul a paros 3-al oszthato szamok: ");

			bool contains = false;

			for (i = 9; i < restaurants.Count; i++)
			{
				if (restaurants[i] % 2 == 0 && restaurants[i] % 3 == 0)
				{
					contains = true;
					Console.Write($"{restaurants[i]} ");
				}
			}

			Console.WriteLine(contains
				? ""
				: "Nincs ilyen szam."
			);

			Console.Write("\nElso 9 etterem kozul a 40 alatti es 70 feletti szamok: ");

			contains = false;

			for (i = 0; i < restaurants.Count / 2; i++)
			{
				if (restaurants[i] < 40 || restaurants[i] > 70)
				{
					contains = true;
					Console.Write($"{restaurants[i]} ");
				}
			}

			Console.WriteLine(contains
				? ""
				: "Nincs ilyen szam."
			);

			double sum = 0;

			for (i = 0; i < restaurants.Count; i++)
				sum += restaurants[i];

			Console.WriteLine($"\nSzamok atlaga: {Math.Round(sum / restaurants.Count, 2)}");

			int cnt = 0;
			sum = 0;

			for (i = 0; i < restaurants.Count; i++)
			{
				if (restaurants[i] % 2 != 0)
				{
					cnt++;
					sum += restaurants[i];
				}
			}

			Console.WriteLine($"\nParatlan szamok atlaga: {Math.Round(sum / cnt, 2)}");

			int min = restaurants[0];
			int minI = 0;

			for (i = 1; i < restaurants.Count; i++)
			{
				if (restaurants[i] < min)
				{
					min = restaurants[i];
					minI = i;
				}
			}

			Console.WriteLine($"\nA legkisebb szam {min} a(z) {minI}. etteremben");

			for (i = 0; i < 3; i++)
				restaurants.Add(rand.Next(30, 81));

			List<int> ordered = restaurants;
			ordered.Sort();

			Console.Write($"\nNovekvo sorrend: ");

			for (i = 0; i < ordered.Count - 1; i++)
				Console.Write($"{ordered[i]} ");

			Console.WriteLine(ordered[i]);

			int[] copy = new int[restaurants.Count];
			restaurants.CopyTo(copy);

			cnt = 0;

			for (i = 0; i < copy.Length; i++)
			{
				if (copy[i] % 2 != 0)
					cnt++;
			}

			Console.WriteLine($"\nA masolt listaban paratlan szamok szama: {cnt}");
			Console.WriteLine("\n\nNyomj barmien gombot uj szamok generalasahoz (^C a kilepeshez)");

			Console.ReadKey();
		}
	}
}
